# https://2engenheiros.com/2017/05/29/como-calcular-qui-quadrado-no-r/

data("HairEyeColor")

HairEyeColor[,,] # Mostra todos os dados
HairEyeColor[,,"Male"] # Mostra todos os dados do gênero masculino
HairEyeColor[1,,] # Mostra todos os dados daqueles que têm cabelo preto

chisq.test(HairEyeColor[,,1])
chisq.test(HairEyeColor[,,2])

hec_soma <- HairEyeColor[,,1] + HairEyeColor[,,2]
hec_soma
chisq.test(hec_soma)

# GERANDO TABELA QUI-QUADRADO
# Setando p-values
p <- c(0.995, 0.99, 0.975, 0.95, 0.90, 0.10, 0.05, 0.025, 0.01, 0.005)
p <- rev(p)
# Setando os graus de liberdade
df <- seq(1,20)

# Calculando a matrix de estatisticas chisq
m <- outer(p, df, function(x,y) qchisq(x,y))

# Transpose para uma melhor visualização
m <- t(m)

# Setando os nomes das colunas e linhas
colnames(m) <- p
rownames(m) <- df

#Arredondando o resultado para 3 casas decimais
mRound <- round(m, 4)

mRound