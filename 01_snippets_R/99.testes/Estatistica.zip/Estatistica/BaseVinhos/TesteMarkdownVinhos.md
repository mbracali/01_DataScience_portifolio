---
title: "AnaliseVinhos"
author: "Angelo Antonello Borges"
date: "02/06/2019"
output:
  html_document: 
    fig_caption: yes
    fig_width: 14
    fig_height: 12
    highlight: haddock
    keep_md: yes
    number_sections: yes
    theme: simplex
    toc: yes
    df_print: paged
    code_folding: hide
editor_options: 
  chunk_output_type: inline
---







# Informações sobre o Dataset

O dataset possui 6497 registros e 14 atributos. Sendo a maior parte atributos referentes a propriedades quimicas e físicas dos vinhos.

O dataset, aqui nomeado de 'vinhos', possui os seguintes atributos:

```
##  [1] "id_vinho"           "fixedacidity"       "volatileacidity"   
##  [4] "citricacid"         "residualsugar"      "chlorides"         
##  [7] "freesulfurdioxide"  "totalsulfurdioxide" "density"           
## [10] "pH"                 "sulphates"          "alcohol"           
## [13] "quality"            "Vinho"
```

## Tamanho do dataset

```
## [1] 6497   14
```

## Identificação das propriedades

### [1] "id_vinho" = Identificador do vinho (código - número inteiro):

### [2] "fixedacidity" = Acidez Fixa (g/dm^3):

```
##  num [1:6497] 6.6 6.7 10.6 5.4 6.7 6.8 6.6 7.2 5.1 6.2 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   3.800   6.400   7.000   7.215   7.700  15.900
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-2-1.png)<!-- -->

### [3] "volatileacidity" = Acidez Voláil (g/dm^3):

```
##  num [1:6497] 0.24 0.34 0.31 0.18 0.3 0.5 0.61 0.66 0.26 0.22 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.0800  0.2300  0.2900  0.3397  0.4000  1.5800
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-3-1.png)<!-- -->

### [4] "citricacid" = Ácido Cítrico (g/dm^3):

```
##  num [1:6497] 0.35 0.43 0.49 0.24 0.44 0.11 0 0.33 0.33 0.2 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.0000  0.2500  0.3100  0.3186  0.3900  1.6600
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-4-1.png)<!-- -->

### [5] "residualsugar" = Açúcar Residual (g/dm^3):

```
##  num [1:6497] 7.7 1.6 2.2 4.8 18.8 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##    0.60    1.80    3.00    5.44    8.10   45.80
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-5-1.png)<!-- -->

### [6] "chlorides" = Cloretos (g/dm^3): 

```
##  num [1:6497] 0.031 0.041 0.063 0.041 0.057 0.075 0.069 0.068 0.027 0.035 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
## 0.00900 0.03800 0.04700 0.05603 0.06500 0.61100
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-6-1.png)<!-- -->

### [7] "freesulfurdioxide" = Livre de  Dióxido de Enxofre (g/dm^3):

```
##  num [1:6497] 36 29 18 30 65 16 4 34 46 58 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##    1.00   17.00   29.00   30.53   41.00  289.00
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-7-1.png)<!-- -->

### [8] "totalsulfurdioxide" = Total de Dióxido de Enxofre (g/dm^3):

```
##  num [1:6497] 135 114 40 113 224 49 8 102 113 184 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##     6.0    77.0   118.0   115.7   156.0   440.0
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-8-1.png)<!-- -->

### [9] "density" = Densidade (g/cm^3): 

```
##  num [1:6497] 0.994 0.99 0.998 0.994 1 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.9871  0.9923  0.9949  0.9947  0.9970  1.0140
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-9-1.png)<!-- -->

### [10] "pH" = pH: 

```
##  num [1:6497] 3.19 3.23 3.14 3.42 3.11 3.36 3.33 3.27 3.35 3.11 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   2.720   3.110   3.210   3.219   3.320   4.010
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-10-1.png)<!-- -->

### [11] "sulphates" = Sulfatos (g/dm^3):

```
##  num [1:6497] 0.37 0.44 0.51 0.4 0.53 0.79 0.37 0.78 0.43 0.53 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.2200  0.4300  0.5100  0.5313  0.6000  2.0000
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-11-1.png)<!-- -->

### [12] "alcohol" = Percentual alcólico (% by volume): 

```
##  num [1:6497] 10.5 12.6 9.8 9.4 9.1 9.5 10.4 12.8 11.4 9 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##  0.9567  9.5000 10.3000 10.4862 11.3000 14.9000
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-12-1.png)<!-- -->

### [13] "quality" = Qualidade do vinho: 

```
##  int [1:6497] 5 6 6 6 5 5 4 6 7 6 ...
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   3.000   5.000   6.000   5.818   6.000   9.000
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-13-1.png)<!-- -->

### [14] "Vinho" = Tipo do Vinho: 

```
##  Factor w/ 2 levels "RED","WHITE": 2 2 1 2 2 1 1 1 2 2 ...
```

```
##   RED WHITE 
##  1599  4898
```


## Análise dos Dados

Para termos uma ideia geral dos dados, são listados abaixo apenas os 6 primeiros registros:
<div data-pagedtable="false">
  <script data-pagedtable-source type="application/json">
{"columns":[{"label":[""],"name":["_rn_"],"type":[""],"align":["left"]},{"label":["id_vinho"],"name":[1],"type":["int"],"align":["right"]},{"label":["fixedacidity"],"name":[2],"type":["dbl"],"align":["right"]},{"label":["volatileacidity"],"name":[3],"type":["dbl"],"align":["right"]},{"label":["citricacid"],"name":[4],"type":["dbl"],"align":["right"]},{"label":["residualsugar"],"name":[5],"type":["dbl"],"align":["right"]},{"label":["chlorides"],"name":[6],"type":["dbl"],"align":["right"]},{"label":["freesulfurdioxide"],"name":[7],"type":["dbl"],"align":["right"]},{"label":["totalsulfurdioxide"],"name":[8],"type":["dbl"],"align":["right"]},{"label":["density"],"name":[9],"type":["dbl"],"align":["right"]},{"label":["pH"],"name":[10],"type":["dbl"],"align":["right"]},{"label":["sulphates"],"name":[11],"type":["dbl"],"align":["right"]},{"label":["alcohol"],"name":[12],"type":["dbl"],"align":["right"]},{"label":["quality"],"name":[13],"type":["int"],"align":["right"]},{"label":["Vinho"],"name":[14],"type":["fctr"],"align":["left"]}],"data":[{"1":"1","2":"6.6","3":"0.24","4":"0.35","5":"7.70","6":"0.031","7":"36","8":"135","9":"0.99380","10":"3.19","11":"0.37","12":"10.5","13":"5","14":"WHITE","_rn_":"1"},{"1":"2","2":"6.7","3":"0.34","4":"0.43","5":"1.60","6":"0.041","7":"29","8":"114","9":"0.99014","10":"3.23","11":"0.44","12":"12.6","13":"6","14":"WHITE","_rn_":"2"},{"1":"3","2":"10.6","3":"0.31","4":"0.49","5":"2.20","6":"0.063","7":"18","8":"40","9":"0.99760","10":"3.14","11":"0.51","12":"9.8","13":"6","14":"RED","_rn_":"3"},{"1":"4","2":"5.4","3":"0.18","4":"0.24","5":"4.80","6":"0.041","7":"30","8":"113","9":"0.99445","10":"3.42","11":"0.40","12":"9.4","13":"6","14":"WHITE","_rn_":"4"},{"1":"5","2":"6.7","3":"0.30","4":"0.44","5":"18.75","6":"0.057","7":"65","8":"224","9":"0.99956","10":"3.11","11":"0.53","12":"9.1","13":"5","14":"WHITE","_rn_":"5"},{"1":"6","2":"6.8","3":"0.50","4":"0.11","5":"1.50","6":"0.075","7":"16","8":"49","9":"0.99545","10":"3.36","11":"0.79","12":"9.5","13":"5","14":"RED","_rn_":"6"}],"options":{"columns":{"min":{},"max":[10]},"rows":{"min":[10],"max":[10]},"pages":{}}}
  </script>
</div>

Como pode ser analizado, todos os atributos são numéricos, exceto o atributo 'quality', que 
é fatorizado.

Também entendemos que as propriedades "fixedacidity", "volatileacidity" e "citricacid" compoem a acidez total do vinho. Dessa forma, geramos uma nova propriedade chamada "totalacidity" para sumariza-las.


```r
vinhos$totalacidity <- with(vinhos, fixedacidity + volatileacidity + citricacid)
str(vinhos[,"totalacidity"])
```

```
##  num [1:6497] 7.19 7.47 11.4 5.82 7.44 7.41 7.21 8.19 5.69 6.62 ...
```

```r
summary(vinhos[,"totalacidity"])
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
##   4.130   7.020   7.600   7.874   8.380  17.045
```

```r
# drops <- c("fixedacidity","volatileacidity","citricacid")
# vinhos <- vinhos[ , !(names(vinhos) %in% drops)]

## Realizando o plot do histogram e boxplot

#Alinhando os dois eixos.
totalacidity.p1 = qplot(x = 1, y = totalacidity, data = vinhos, xlab = "", geom = 'boxplot') + 
  coord_flip() +
  ylim(min(vinhos$totalacidity),max(vinhos$totalacidity))

totalacidity.p2 = qplot(x = totalacidity, data = vinhos, geom = 'histogram')+
  xlim(min(vinhos$totalacidity),max(vinhos$totalacidity))

#Mostrando o resultado
plot_grid(totalacidity.p1, totalacidity.p2, labels = c("A", "B"), align = "v",ncol = 1)
```

```
## `stat_bin()` using `bins = 30`. Pick better value with `binwidth`.
```

```
## Warning: Removed 2 rows containing missing values (geom_bar).
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-16-1.png)<!-- -->

### Análise Bivariada


```r
vinhos2 <- vinhos %>% mutate_if(is.factor, as.numeric)

vinhos2$winetype <- with(vinhos2, Vinho)
drops <- c("Vinho","var13","var14","var15")
vinhos2 <- vinhos2[ , !(names(vinhos2) %in% drops)]

glimpse(vinhos2)
```

```
## Observations: 6,497
## Variables: 15
## $ id_vinho           <int> 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, ...
## $ fixedacidity       <dbl> 6.6, 6.7, 10.6, 5.4, 6.7, 6.8, 6.6, 7.2, 5....
## $ volatileacidity    <dbl> 0.240, 0.340, 0.310, 0.180, 0.300, 0.500, 0...
## $ citricacid         <dbl> 0.35, 0.43, 0.49, 0.24, 0.44, 0.11, 0.00, 0...
## $ residualsugar      <dbl> 7.70, 1.60, 2.20, 4.80, 18.75, 1.50, 1.60, ...
## $ chlorides          <dbl> 0.031, 0.041, 0.063, 0.041, 0.057, 0.075, 0...
## $ freesulfurdioxide  <dbl> 36, 29, 18, 30, 65, 16, 4, 34, 46, 58, 54, ...
## $ totalsulfurdioxide <dbl> 135, 114, 40, 113, 224, 49, 8, 102, 113, 18...
## $ density            <dbl> 0.99380, 0.99014, 0.99760, 0.99445, 0.99956...
## $ pH                 <dbl> 3.19, 3.23, 3.14, 3.42, 3.11, 3.36, 3.33, 3...
## $ sulphates          <dbl> 0.37, 0.44, 0.51, 0.40, 0.53, 0.79, 0.37, 0...
## $ alcohol            <dbl> 10.50, 12.60, 9.80, 9.40, 9.10, 9.50, 10.40...
## $ quality            <int> 5, 6, 6, 6, 5, 5, 4, 6, 7, 6, 5, 6, 6, 6, 6...
## $ totalacidity       <dbl> 7.190, 7.470, 11.400, 5.820, 7.440, 7.410, ...
## $ winetype           <dbl> 2, 2, 1, 2, 2, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2...
```

Correlation, Variance and Covariance (Matrices)


```r
kable(cor(vinhos2)) %>% kable_styling("striped", full_width = T, font_size = 9) %>% row_spec(0, angle = -45)
```

<table class="table table-striped" style="font-size: 9px; margin-left: auto; margin-right: auto;">
 <thead>
  <tr>
   <th style="text-align:left;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);">   </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> id_vinho </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> fixedacidity </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> volatileacidity </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> citricacid </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> residualsugar </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> chlorides </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> freesulfurdioxide </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> totalsulfurdioxide </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> density </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> pH </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> sulphates </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> alcohol </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> quality </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> totalacidity </th>
   <th style="text-align:right;-webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg);"> winetype </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> id_vinho </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> -0.0123941 </td>
   <td style="text-align:right;"> -0.0028912 </td>
   <td style="text-align:right;"> 0.0114076 </td>
   <td style="text-align:right;"> 0.0140912 </td>
   <td style="text-align:right;"> -0.0112208 </td>
   <td style="text-align:right;"> 0.0112036 </td>
   <td style="text-align:right;"> 0.0271266 </td>
   <td style="text-align:right;"> -0.0109458 </td>
   <td style="text-align:right;"> -0.0198247 </td>
   <td style="text-align:right;"> -0.0173216 </td>
   <td style="text-align:right;"> -0.0041137 </td>
   <td style="text-align:right;"> -0.0074408 </td>
   <td style="text-align:right;"> -0.0107249 </td>
   <td style="text-align:right;"> 0.0328549 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> fixedacidity </td>
   <td style="text-align:right;"> -0.0123941 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> 0.2190083 </td>
   <td style="text-align:right;"> 0.3244357 </td>
   <td style="text-align:right;"> -0.1130501 </td>
   <td style="text-align:right;"> 0.2981948 </td>
   <td style="text-align:right;"> -0.2827354 </td>
   <td style="text-align:right;"> -0.3290539 </td>
   <td style="text-align:right;"> 0.4646964 </td>
   <td style="text-align:right;"> -0.2527005 </td>
   <td style="text-align:right;"> 0.2995677 </td>
   <td style="text-align:right;"> -0.1016319 </td>
   <td style="text-align:right;"> -0.0767432 </td>
   <td style="text-align:right;"> 0.9939573 </td>
   <td style="text-align:right;"> -0.4867398 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> volatileacidity </td>
   <td style="text-align:right;"> -0.0028912 </td>
   <td style="text-align:right;"> 0.2190083 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> -0.3779813 </td>
   <td style="text-align:right;"> -0.1998426 </td>
   <td style="text-align:right;"> 0.3771243 </td>
   <td style="text-align:right;"> -0.3525573 </td>
   <td style="text-align:right;"> -0.4144762 </td>
   <td style="text-align:right;"> 0.2701209 </td>
   <td style="text-align:right;"> 0.2614544 </td>
   <td style="text-align:right;"> 0.2259837 </td>
   <td style="text-align:right;"> -0.0442946 </td>
   <td style="text-align:right;"> -0.2656995 </td>
   <td style="text-align:right;"> 0.2835964 </td>
   <td style="text-align:right;"> -0.6530356 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> citricacid </td>
   <td style="text-align:right;"> 0.0114076 </td>
   <td style="text-align:right;"> 0.3244357 </td>
   <td style="text-align:right;"> -0.3779813 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> 0.1421754 </td>
   <td style="text-align:right;"> 0.0389980 </td>
   <td style="text-align:right;"> 0.1331258 </td>
   <td style="text-align:right;"> 0.1952420 </td>
   <td style="text-align:right;"> 0.0949698 </td>
   <td style="text-align:right;"> -0.3298082 </td>
   <td style="text-align:right;"> 0.0561973 </td>
   <td style="text-align:right;"> -0.0080199 </td>
   <td style="text-align:right;"> 0.0855317 </td>
   <td style="text-align:right;"> 0.3628883 </td>
   <td style="text-align:right;"> 0.1873965 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> residualsugar </td>
   <td style="text-align:right;"> 0.0140912 </td>
   <td style="text-align:right;"> -0.1130501 </td>
   <td style="text-align:right;"> -0.1998426 </td>
   <td style="text-align:right;"> 0.1421754 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> -0.1301670 </td>
   <td style="text-align:right;"> 0.4064856 </td>
   <td style="text-align:right;"> 0.4984003 </td>
   <td style="text-align:right;"> 0.5431964 </td>
   <td style="text-align:right;"> -0.2698648 </td>
   <td style="text-align:right;"> -0.1879092 </td>
   <td style="text-align:right;"> -0.3528744 </td>
   <td style="text-align:right;"> -0.0373719 </td>
   <td style="text-align:right;"> -0.1144092 </td>
   <td style="text-align:right;"> 0.3508627 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> chlorides </td>
   <td style="text-align:right;"> -0.0112208 </td>
   <td style="text-align:right;"> 0.2981948 </td>
   <td style="text-align:right;"> 0.3771243 </td>
   <td style="text-align:right;"> 0.0389980 </td>
   <td style="text-align:right;"> -0.1301670 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> -0.1950448 </td>
   <td style="text-align:right;"> -0.2796304 </td>
   <td style="text-align:right;"> 0.3669833 </td>
   <td style="text-align:right;"> 0.0447080 </td>
   <td style="text-align:right;"> 0.3955933 </td>
   <td style="text-align:right;"> -0.2561282 </td>
   <td style="text-align:right;"> -0.2006655 </td>
   <td style="text-align:right;"> 0.3273324 </td>
   <td style="text-align:right;"> -0.5126782 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> freesulfurdioxide </td>
   <td style="text-align:right;"> 0.0112036 </td>
   <td style="text-align:right;"> -0.2827354 </td>
   <td style="text-align:right;"> -0.3525573 </td>
   <td style="text-align:right;"> 0.1331258 </td>
   <td style="text-align:right;"> 0.4064856 </td>
   <td style="text-align:right;"> -0.1950448 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> 0.7209341 </td>
   <td style="text-align:right;"> 0.0277254 </td>
   <td style="text-align:right;"> -0.1458539 </td>
   <td style="text-align:right;"> -0.1884572 </td>
   <td style="text-align:right;"> -0.1726250 </td>
   <td style="text-align:right;"> 0.0554631 </td>
   <td style="text-align:right;"> -0.2919589 </td>
   <td style="text-align:right;"> 0.4716437 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> totalsulfurdioxide </td>
   <td style="text-align:right;"> 0.0271266 </td>
   <td style="text-align:right;"> -0.3290539 </td>
   <td style="text-align:right;"> -0.4144762 </td>
   <td style="text-align:right;"> 0.1952420 </td>
   <td style="text-align:right;"> 0.4984003 </td>
   <td style="text-align:right;"> -0.2796304 </td>
   <td style="text-align:right;"> 0.7209341 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> 0.0318256 </td>
   <td style="text-align:right;"> -0.2384131 </td>
   <td style="text-align:right;"> -0.2757268 </td>
   <td style="text-align:right;"> -0.2563239 </td>
   <td style="text-align:right;"> -0.0413855 </td>
   <td style="text-align:right;"> -0.3360621 </td>
   <td style="text-align:right;"> 0.7003572 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> density </td>
   <td style="text-align:right;"> -0.0109458 </td>
   <td style="text-align:right;"> 0.4646964 </td>
   <td style="text-align:right;"> 0.2701209 </td>
   <td style="text-align:right;"> 0.0949698 </td>
   <td style="text-align:right;"> 0.5431964 </td>
   <td style="text-align:right;"> 0.3669833 </td>
   <td style="text-align:right;"> 0.0277254 </td>
   <td style="text-align:right;"> 0.0318256 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> 0.0104605 </td>
   <td style="text-align:right;"> 0.2616941 </td>
   <td style="text-align:right;"> -0.6876216 </td>
   <td style="text-align:right;"> -0.3103763 </td>
   <td style="text-align:right;"> 0.4760152 </td>
   <td style="text-align:right;"> -0.3968140 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> pH </td>
   <td style="text-align:right;"> -0.0198247 </td>
   <td style="text-align:right;"> -0.2527005 </td>
   <td style="text-align:right;"> 0.2614544 </td>
   <td style="text-align:right;"> -0.3298082 </td>
   <td style="text-align:right;"> -0.2698648 </td>
   <td style="text-align:right;"> 0.0447080 </td>
   <td style="text-align:right;"> -0.1458539 </td>
   <td style="text-align:right;"> -0.2384131 </td>
   <td style="text-align:right;"> 0.0104605 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> 0.1921234 </td>
   <td style="text-align:right;"> 0.1206833 </td>
   <td style="text-align:right;"> 0.0195057 </td>
   <td style="text-align:right;"> -0.2395430 </td>
   <td style="text-align:right;"> -0.3291287 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> sulphates </td>
   <td style="text-align:right;"> -0.0173216 </td>
   <td style="text-align:right;"> 0.2995677 </td>
   <td style="text-align:right;"> 0.2259837 </td>
   <td style="text-align:right;"> 0.0561973 </td>
   <td style="text-align:right;"> -0.1879092 </td>
   <td style="text-align:right;"> 0.3955933 </td>
   <td style="text-align:right;"> -0.1884572 </td>
   <td style="text-align:right;"> -0.2757268 </td>
   <td style="text-align:right;"> 0.2616941 </td>
   <td style="text-align:right;"> 0.1921234 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> -0.0059749 </td>
   <td style="text-align:right;"> 0.0384854 </td>
   <td style="text-align:right;"> 0.3124883 </td>
   <td style="text-align:right;"> -0.4872180 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> alcohol </td>
   <td style="text-align:right;"> -0.0041137 </td>
   <td style="text-align:right;"> -0.1016319 </td>
   <td style="text-align:right;"> -0.0442946 </td>
   <td style="text-align:right;"> -0.0080199 </td>
   <td style="text-align:right;"> -0.3528744 </td>
   <td style="text-align:right;"> -0.2561282 </td>
   <td style="text-align:right;"> -0.1726250 </td>
   <td style="text-align:right;"> -0.2563239 </td>
   <td style="text-align:right;"> -0.6876216 </td>
   <td style="text-align:right;"> 0.1206833 </td>
   <td style="text-align:right;"> -0.0059749 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> 0.4350063 </td>
   <td style="text-align:right;"> -0.1010191 </td>
   <td style="text-align:right;"> 0.0404685 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> quality </td>
   <td style="text-align:right;"> -0.0074408 </td>
   <td style="text-align:right;"> -0.0767432 </td>
   <td style="text-align:right;"> -0.2656995 </td>
   <td style="text-align:right;"> 0.0855317 </td>
   <td style="text-align:right;"> -0.0373719 </td>
   <td style="text-align:right;"> -0.2006655 </td>
   <td style="text-align:right;"> 0.0554631 </td>
   <td style="text-align:right;"> -0.0413855 </td>
   <td style="text-align:right;"> -0.3103763 </td>
   <td style="text-align:right;"> 0.0195057 </td>
   <td style="text-align:right;"> 0.0384854 </td>
   <td style="text-align:right;"> 0.4350063 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> -0.0942397 </td>
   <td style="text-align:right;"> 0.1193233 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> totalacidity </td>
   <td style="text-align:right;"> -0.0107249 </td>
   <td style="text-align:right;"> 0.9939573 </td>
   <td style="text-align:right;"> 0.2835964 </td>
   <td style="text-align:right;"> 0.3628883 </td>
   <td style="text-align:right;"> -0.1144092 </td>
   <td style="text-align:right;"> 0.3273324 </td>
   <td style="text-align:right;"> -0.2919589 </td>
   <td style="text-align:right;"> -0.3360621 </td>
   <td style="text-align:right;"> 0.4760152 </td>
   <td style="text-align:right;"> -0.2395430 </td>
   <td style="text-align:right;"> 0.3124883 </td>
   <td style="text-align:right;"> -0.1010191 </td>
   <td style="text-align:right;"> -0.0942397 </td>
   <td style="text-align:right;"> 1.0000000 </td>
   <td style="text-align:right;"> -0.5124603 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> winetype </td>
   <td style="text-align:right;"> 0.0328549 </td>
   <td style="text-align:right;"> -0.4867398 </td>
   <td style="text-align:right;"> -0.6530356 </td>
   <td style="text-align:right;"> 0.1873965 </td>
   <td style="text-align:right;"> 0.3508627 </td>
   <td style="text-align:right;"> -0.5126782 </td>
   <td style="text-align:right;"> 0.4716437 </td>
   <td style="text-align:right;"> 0.7003572 </td>
   <td style="text-align:right;"> -0.3968140 </td>
   <td style="text-align:right;"> -0.3291287 </td>
   <td style="text-align:right;"> -0.4872180 </td>
   <td style="text-align:right;"> 0.0404685 </td>
   <td style="text-align:right;"> 0.1193233 </td>
   <td style="text-align:right;"> -0.5124603 </td>
   <td style="text-align:right;"> 1.0000000 </td>
  </tr>
</tbody>
</table>

```r
ggpairs(data = vinhos2, columns = c(2,3,4,5,6,7,8,9,12,13,14,15))
```

![](TesteMarkdownVinhos_files/figure-html/unnamed-chunk-18-1.png)<!-- -->

A relação entre quality e alcohol, chlorides e density é alta. 

Dessa forma, ficamos interessados em identificar quais fatores influemciam a qualidade

Também vemos que :
residualsugar, density e alcohol tem alta correlação;
pH e fixedacidity tem alta correlação;

Para os plots abaixo, considerar:
Alaranjado : média,
Azul : mediana


```r
ggplot(data = vinhos2, aes(x = quality, y = chlorides)) +
  geom_point(alpha = 0.5, position = position_jitter(h = 0)) +
  geom_line(stat = 'summary', fun.y = mean, size = 2, color = 'orange') +
  geom_line(stat = 'summary', fun.y = median, size = 2, color = 'steelblue') +
  coord_cartesian(ylim = c(0.02,0.07)) +
  scale_x_continuous(breaks = seq(2,10,1))
ggplot(data = vinhos2, aes(x = as.factor(quality), y = chlorides, fill = as.factor(quality))) + geom_boxplot() + coord_cartesian(ylim = c(0.01,0.07))
```

<img src="TesteMarkdownVinhos_files/figure-html/unnamed-chunk-19-1.png" width="100%" /><img src="TesteMarkdownVinhos_files/figure-html/unnamed-chunk-19-2.png" width="100%" />

