# install.packages('cowplot', dependencies = T)
library(cowplot)
library(ggplot2)
library(dplyr)
library(GGally)
library(gridExtra)

filename <- file.choose()
vinhos <- read.csv2(filename, skip=0, sep = ';')
name <- basename(filename)
names(vinhos)

vinhos$totalacidity <- with(vinhos, fixedacidity + volatileacidity + citricacid)
names(vinhos)

fix(vinhos)

winetype<-as.factor(c("Red","White"))
winetype
unclass(winetype)
vinhos[,"Vinho"] = winetype

glimpse(vinhos)
vinhos2 <- vinhos %>% mutate_if(is.factor, as.numeric)

cor(vinhos2)